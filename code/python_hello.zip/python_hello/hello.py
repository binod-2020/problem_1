class Greeter:
    def __init__(self):
        self.message = 'Hello world!'
        # print self.message
